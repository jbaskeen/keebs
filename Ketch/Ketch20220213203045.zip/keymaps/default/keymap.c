#include "Ketch20220213203045.h"
enum custom_keycodes {
  M_IME = SAFE_RANGE
};

bool process_record_user(uint16_t keycode, keyrecord_t *record) {
  if (record->event.pressed) {
    switch(keycode) {
      case M_IME:
        SEND_STRING(SS_DOWN(X_LSHIFT)SS_DOWN(X_LALT));
        return false;
    }
  }
  else {
    switch(keycode) {
      case M_IME:
        SEND_STRING(SS_UP(X_LSHIFT)SS_UP(X_LALT));
        return false;
    }
  }
  return true;
};
const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
  [0] = LAYOUT(KC_ESC, KC_Q, KC_W, KC_E, KC_R, KC_T, KC_Y, KC_U, KC_I, KC_O, KC_P, KC_BSPC, KC_TAB, KC_A, KC_S, KC_D, KC_F, KC_G, KC_H, KC_J, KC_K, KC_L, KC_SCLN, KC_ENT, KC_LSFT, KC_Z, KC_X, KC_C, KC_V, KC_B, KC_N, KC_M, KC_COMM, KC_DOT, KC_SLSH, KC_RSFT, KC_LCTL, KC_LALT, KC_LGUI, KC_NO, KC_SPC, KC_NO, KC_RALT, KC_RSFT, KC_RCTL, MO(1)),
  [1] = LAYOUT(KC_GRV, KC_EXLM, KC_AT, KC_HASH, KC_DLR, KC_PERC, KC_CIRC, KC_AMPR, KC_ASTR, KC_LPRN, KC_RPRN, KC_DEL, KC_TRNS, KC_BSLS, KC_QUOT, KC_MINS, KC_EQL, KC_LBRC, KC_RBRC, KC_DOWN, KC_UP, KC_LEFT, KC_RIGHT, KC_TRNS, KC_TRNS, KC_ESC, BL_STEP, KC_PSCR, KC_TRNS, KC_TRNS, KC_TRNS, KC_MSTP, KC_MPLY, KC_MPRV, KC_MNXT, KC_TRNS, KC_LCTL, KC_LALT, KC_LGUI, KC_NO, KC_SPC, KC_NO, KC_RALT, KC_RSFT, KC_RCTL, KC_TRNS)
};

void process_indicator_update(layer_state_t state, uint8_t usb_led) {
  for (int i = 0; i < 10; i++) {
    setrgb(0, 0, 0, (LED_TYPE *)&led[i]);
  }
  setrgb(200, 23, 23, (LED_TYPE *)&led[0]);
  setrgb(200, 23, 23, (LED_TYPE *)&led[1]);
  setrgb(200, 23, 23, (LED_TYPE *)&led[2]);
  setrgb(200, 23, 23, (LED_TYPE *)&led[3]);
  setrgb(200, 23, 23, (LED_TYPE *)&led[4]);
  setrgb(200, 23, 23, (LED_TYPE *)&led[5]);
  setrgb(200, 23, 23, (LED_TYPE *)&led[6]);
  setrgb(200, 23, 23, (LED_TYPE *)&led[7]);
  setrgb(200, 23, 23, (LED_TYPE *)&led[8]);
  setrgb(200, 23, 23, (LED_TYPE *)&led[9]);

  rgblight_set();
};

void keyboard_post_init_user(void) {
  process_indicator_update(layer_state, host_keyboard_leds());
};

void led_set_user(uint8_t usb_led) {
  process_indicator_update(layer_state, host_keyboard_leds());
};

layer_state_t layer_state_set_user(layer_state_t state) {
  process_indicator_update(state, host_keyboard_leds());
    return state;
};

