#ifndef MUSE_H
#define MUSE_H

#include "quantum.h"
#include "process_audio.h"

uint8_t muse_clock_pulse(void);

#endif
