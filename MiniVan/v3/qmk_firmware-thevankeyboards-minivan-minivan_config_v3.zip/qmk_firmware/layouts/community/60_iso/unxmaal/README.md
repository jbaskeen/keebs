Unxmaal's GH60 Layout
=====================
* Mostly stolen from /u/robotmaxtron

##Quantum MK Firmware
For the full Quantum feature list, see the parent readme.md.

* Standard Mac ANSI layout
* Spacebar acts as space when tapped, Fn when held
* Menu acts as menu when tapped, Fn2 when held
* Layer1:
  * Top row = `~, F1-F12, Del
  * JKIL = arrow cluster
* Layer2:
  * Top row = media controls
  * JKIL = PgDn/Up/Home/Insert
  * Backspace = Reset

### Additional Credits
Keymap has been based on various keymaps available from the QMK Repo for the GH60-SATAN and KC60 keyboards.

![wiring](https://i.imgur.com/8b8T1fQ.jpg)