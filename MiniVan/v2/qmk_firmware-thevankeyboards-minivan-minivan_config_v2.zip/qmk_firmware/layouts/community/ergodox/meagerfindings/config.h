#undef VENDOR_ID
#define VENDOR_ID       0xFEED
#undef PRODUCT_ID
#define PRODUCT_ID      0x1307
#undef DEVICE_VER
#define DEVICE_VER      0x0001
#undef MANUFACTURER
#define MANUFACTURER    meagerfindings
#undef PRODUCT
#define PRODUCT         ErgoDox
#undef DESCRIPTION
#define DESCRIPTION     meagerfindings firmware for Ergodox

#define USB_MAX_POWER_CONSUMPTION 500

#undef MOUSEKEY_INTERVAL
#define MOUSEKEY_INTERVAL       20
#undef MOUSEKEY_DELAY
#define MOUSEKEY_DELAY          0
#undef MOUSEKEY_TIME_TO_MAX
#define MOUSEKEY_TIME_TO_MAX    18
#undef MOUSEKEY_MAX_SPEED
#define MOUSEKEY_MAX_SPEED      4

#undef TAPPING_TERM
#define TAPPING_TERM 200
